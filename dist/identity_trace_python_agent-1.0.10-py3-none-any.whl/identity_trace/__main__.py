from . import initialize

if __name__ == "__main__":
    initialize()